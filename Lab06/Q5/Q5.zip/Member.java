public class Member 
{
	//Instance fields
    private String name;
    private Role role;
	
	//Constructor
	public Member(String name, Role role) {
        this.name = name;
        this.role = role;
    }

	public void setRole(Role r) { this.role = r; }
	
	//Assessor method
	public String getName() { return name; }
	public Role getRole() { return role; }
    public String getNameAndRole() {return role.getNameAndRole(this);}
    public String genTeamContactMsg(Team t) {return role.genTeamContactMsg(t);}

	public String toString() { return name; }
}